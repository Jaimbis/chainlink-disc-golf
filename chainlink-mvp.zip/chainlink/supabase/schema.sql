-- Run in Supabase SQL Editor. Public reads, authenticated writes, owner-only modifications.
create table if not exists public.courses (
 id bigint generated always as identity primary key,
 name text not null unique,
 city text not null,
 state text not null default 'MI'
);
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null check (char_length(username) between 2 and 30),
 created_at timestamptz not null default now()
);
create table if not exists public.messages (
 id bigint generated always as identity primary key,
 course_id bigint not null references public.courses(id),
 user_id uuid not null references auth.users(id),
 body text not null check (char_length(body) between 1 and 1000),
 created_at timestamptz not null default now()
);
create table if not exists public.posts (
 id bigint generated always as identity primary key,
 course_id bigint not null references public.courses(id),
 user_id uuid not null references auth.users(id),
 kind text not null check(kind in ('lost','found','round')),
 title text not null check(char_length(title) between 1 and 100),
 body text not null check(char_length(body) between 1 and 2000),
 contact text check(char_length(contact) <= 150),
 created_at timestamptz not null default now()
);
create table if not exists public.reports (
 id bigint generated always as identity primary key,
 reporter_id uuid not null references auth.users(id),
 message_id bigint references public.messages(id),
 post_id bigint references public.posts(id),
 reason text not null check(char_length(reason) between 3 and 500),
 created_at timestamptz not null default now(),
 check ((message_id is not null)::int + (post_id is not null)::int = 1)
);
create table if not exists public.blocks (
 blocker_id uuid not null references auth.users(id),
 blocked_id uuid not null references auth.users(id),
 primary key(blocker_id,blocked_id),
 check(blocker_id <> blocked_id)
);
alter table public.courses enable row level security;
alter table public.profiles enable row level security;
alter table public.messages enable row level security;
alter table public.posts enable row level security;
alter table public.reports enable row level security;
alter table public.blocks enable row level security;
create policy "courses readable" on public.courses for select using (true);
create policy "profiles readable" on public.profiles for select using (true);
create policy "profile insert own" on public.profiles for insert to authenticated with check ((select auth.uid())=id);
create policy "profile update own" on public.profiles for update to authenticated using ((select auth.uid())=id) with check ((select auth.uid())=id);
create policy "messages readable" on public.messages for select using (true);
create policy "messages insert own" on public.messages for insert to authenticated with check ((select auth.uid())=user_id);
create policy "messages delete own" on public.messages for delete to authenticated using ((select auth.uid())=user_id);
create policy "posts readable" on public.posts for select using (true);
create policy "posts insert own" on public.posts for insert to authenticated with check ((select auth.uid())=user_id);
create policy "posts update own" on public.posts for update to authenticated using ((select auth.uid())=user_id) with check ((select auth.uid())=user_id);
create policy "posts delete own" on public.posts for delete to authenticated using ((select auth.uid())=user_id);
create policy "reports create own" on public.reports for insert to authenticated with check ((select auth.uid())=reporter_id);
create policy "blocks read own" on public.blocks for select to authenticated using ((select auth.uid())=blocker_id);
create policy "blocks insert own" on public.blocks for insert to authenticated with check ((select auth.uid())=blocker_id);
create policy "blocks delete own" on public.blocks for delete to authenticated using ((select auth.uid())=blocker_id);
insert into public.courses(name,city) values
 ('Burchfield Park - Renegade Trail','Holt'),('Grand Woods Park','Lansing'),('Fitzgerald Park','Grand Ledge'),('Sleepy Hollow State Park','Laingsburg'),('Hickory Hills','Traverse City'),('Flip City','Shelby'),('Hudson Mills Metropark','Dexter'),('Kensington Metropark','Milford'),('Oshtemo Township Park','Kalamazoo'),('Riverside Park','Grand Rapids') on conflict(name) do nothing;
create index if not exists messages_course_time on public.messages(course_id,created_at desc);
create index if not exists posts_course_time on public.posts(course_id,created_at desc);
