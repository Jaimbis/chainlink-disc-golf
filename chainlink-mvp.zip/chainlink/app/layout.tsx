import './globals.css';
export const metadata = {title:'ChainLink | Michigan Disc Golf',description:'Find your disc golf community. Chat, play, and reunite lost discs.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
